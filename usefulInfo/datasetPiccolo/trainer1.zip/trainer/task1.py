import tensorflow as tf
from keras.models import Model
from keras.optimizers import SGD, Adam, RMSprop
from keras.layers import GlobalAveragePooling2D, GlobalMaxPooling2D, Dropout, Dense
from keras.applications.inception_v3 import InceptionV3
from keras import callbacks
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from keras.preprocessing.image import img_to_array, load_img

DATASET_PATH = 'dataset/images1/'
LABEL_PATH = 'dataset/HAM10000_metadata1.csv'


def model():
    # Get the InceptionV3 model so we can do transfer learning
    base_inception = InceptionV3(weights='imagenet', include_top=False,
                                 input_shape=(299, 299, 3))

    out = base_inception.output

    # struttura rete ricercatori che comparano reti neurali
    out = GlobalAveragePooling2D()(out)
    out = Dense(2048, activation='relu')(out)
    out = Dense(2048, activation='relu')(out)
    predictions = Dense(7, activation='softmax')(out)
    model = Model(inputs=base_inception.input, outputs=predictions)
    # model.compile(SGD(lr=.0007, momentum=0.9, decay=0.9), loss='categorical_crossentropy', metrics=['accuracy'])

    return model

    '''

    # struttura rete dei ricercatori dell'ospedale

    predictions = Dense(7, activation='softmax')(out)
    model = Model(inputs=base_inception.input, outputs=predictions)
    model.compile(RMSprop(lr=.001, rho=0.9, decay=0.9, epsilon=0.1), loss='categorical_crossentropy',
                  metrics=['accuracy'])


    # struttura rete codice trovato
    out = GlobalMaxPooling2D()(out)
    out = Dense(512, activation='relu')(out)
    out = Dropout(0.5)(out)
    predictions = Dense(7, activation='softmax')(out)
    model = Model(inputs=base_inception.input, outputs=predictions)
    model.compile(Adam(lr=0.0001, beta_1=0.9, beta_2=0.999, epsilon=None, decay=0.0, amsgrad=True), loss='categorical_crossentropy', metrics=['accuracy'])


    # only if we want to freeze layers
    for layer in base_inception.layers:
        layer.trainable = False

    model.summary()

    # Train the model
    history = model.fit(x_train, y_train, validation_data=(x_val, y_val), epochs=3, verbose=1)

    '''


def main():
    # with tf.device('/device:CPU:0'):
    # file_stream = file_io.FileIO(LABEL_PATH, mode='r')
    data_labels = pd.read_csv(LABEL_PATH)
    # aggiunta riga al pandas frame con il percorso dell'immagine
    data_labels['image_path'] = data_labels.apply(lambda row: (row["image_id"] + ".jpg"), axis=1)
    target_labels = data_labels['dx']

    # load dataset
    train_data = np.array([img_to_array(load_img(DATASET_PATH + img, target_size=(299, 299)))
                           for img in data_labels['image_path'].values.tolist()
                           ]).astype('float32')

    # create train and test datasets
    x_train, x_test, y_train, y_test = train_test_split(train_data, target_labels,
                                                        test_size=0.3,
                                                        stratify=np.array(target_labels),
                                                        random_state=42)

    # create test and validation datasets
    x_test, x_val, y_test, y_val = train_test_split(x_test, y_test,
                                                    test_size=0.5,
                                                    stratify=np.array(y_test),
                                                    random_state=42)

    # get one hot encoded vectors of img labels

    y_train_ohe = pd.get_dummies(y_train.reset_index(drop=True)).as_matrix()
    y_val_ohe = pd.get_dummies(y_val.reset_index(drop=True)).as_matrix()
    y_test_ohe = pd.get_dummies(y_test.reset_index(drop=True)).as_matrix()

    # with tf.device('/device:GPU:0'):
    Model = model()
    Model.compile(SGD(lr=.0007, momentum=0.9, decay=0.9), loss='categorical_crossentropy', metrics=['accuracy'])
    Model.summary()
    ## Adding the callback for TensorBoard
    tensorboard = callbacks.TensorBoard(log_dir='./Graph', histogram_freq=0, write_graph=True, write_images=True)
    Model.fit(x_train, y_train_ohe, validation_data=(x_val, y_val_ohe), epochs=3, verbose=1, callbacks=[tensorboard])

    Model.save('model.h5')


if __name__ == "__main__":
    main()